﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Internetmall.Models.BusinessEntity
{
    public class rankView
    {
        public string commodityId { get; set; }
        public string commodityName { get; set; }
    }
}
