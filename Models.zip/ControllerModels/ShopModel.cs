﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InternetMall.Models
{
    public class ShopID
    {
        public string ID { get; set; }   //店铺ID
    }
}
