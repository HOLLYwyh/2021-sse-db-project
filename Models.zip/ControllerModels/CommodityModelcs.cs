﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InternetMall.Models
{
    public class CommodityID
    {
        public string ID { get; set; }
    }
}
