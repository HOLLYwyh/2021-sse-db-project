﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InternetMall.Models
{
    public class CommodityType
    {
        public string type { get; set; }
    }
}
